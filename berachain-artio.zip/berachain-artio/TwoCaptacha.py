import asyncio
import sys
from typing import Union
from loguru import logger
from curl_cffi.requests import AsyncSession

logger.remove()
logger.add(sys.stdout, colorize=True, format="<g>{time:HH:mm:ss:SSS}</g> | <c>{level}</c> | <level>{message}</level>")


class TwoCaptacha:
    def __init__(self,client_key,proxies):

        self.client_key = client_key
        headers = {'authority': 'artio-80085-faucet-api-cf.berachain.com',
                   'accept': '*/*',
                   'accept-language': 'zh-CN,zh;q=0.9',
                   'cache-control': 'no-cache',
                   'origin': 'https://artio.faucet.berachain.com',
                   'referer': 'https://artio.faucet.berachain.com/',
                   'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36'
                   }

        self.http = AsyncSession(timeout=120, headers=headers, impersonate="chrome120", proxies=proxies)


    async def get_2captcha_google_token(self,acountForLog) -> Union[bool, str]:

        params = {
            "method": "turnstile",
            "key": self.client_key,
            "sitekey": "0x4AAAAAAARdAuciFArKhVwt",
            "pageurl": "https://artio.faucet.berachain.com/",
            "json": 1
        }

        res =await self.http.get('https://2captcha.com/in.php?', params=params)
        if res.json()['status'] != 1:
            logger.warning(f'账号{acountForLog}2captcha创建task失败')
        task_id = res.json()['request']
        await asyncio.sleep(5)
        for _ in range(30):
            response = await self.http.get(f'https://2captcha.com/res.php?key={self.client_key}&action=get&id={task_id}&json=1')
            if response.json()['status'] == 1:
                return response.json()['request']
            else:
                await asyncio.sleep(3)
        return False