import pandas
import asyncio
import sys
import json
from eth_account import Account
from loguru import logger
from web3 import AsyncWeb3, AsyncHTTPProvider
from web3.middleware import async_geth_poa_middleware
from curl_cffi.requests import AsyncSession
import YesCaptacha as YC
import TwoCaptacha as TC
from asyncio.windows_events import WindowsSelectorEventLoopPolicy

logger.remove()
logger.add(sys.stdout, colorize=True, format="<g>{time:HH:mm:ss:SSS}</g> | <c>{level}</c> | <level>{message}</level>")

class BeraChainTools(object):
    def __init__(self,private_key):
        #根据私钥生成钱包账户
        self.account = Account.from_key(private_key)

        #2Captcha的clientkey
        self.client_key = 'your client_key'

        #yesCaptcha的clientkey
        #self.client_key = 'your client_key'

        #代理
        self.proxies = {"https": "http://username:password@proxyserver:port"}

        #设定bera远程rpc结点
        rpc_endpoint = 'https://artio.rpc.berachain.com/'
        self.w3 = AsyncWeb3(AsyncWeb3.AsyncHTTPProvider(rpc_endpoint))
        #custom_provider = AsyncHTTPProvider(rpc_endpoint, request_kwargs=proxy)
        #self.w3 = AsyncWeb3(custom_provider)
        self.w3.middleware_onion.inject(async_geth_poa_middleware, layer=0)

        headers = {
            "authority":"artio-80085-faucet-api-cf.berachain.com",
            "Referer": "https://artio.faucet.berachain.com/",
            "Origin": "https://artio.faucet.berachain.com",
            "Content-Type": "text/plain;charset=UTF-8",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36"
        }
        self.http = AsyncSession(timeout=120,headers= headers, impersonate="chrome120",proxies=self.proxies)

    #获取验证码
    async def get_TaskResult(self,acountForLog):
        #获取领水用的token
        tc = TC.TwoCaptacha(self.client_key,self.proxies)
        bearerToken = await tc.get_2captcha_google_token(acountForLog)
        #yc = YC.YesCaptacha(self.client_key,self.proxies)
        #bearerToken = await yc.get_yescaptcha_google_token(acountForLog)

        self.http.headers.update({"authorization":"Bearer "+ bearerToken})

        return True
    
    async def claim_bera(self):
        """
        bera领水
        :param proxies: http代理
        :return: object
        """
        params = {'address': self.account.address}
        res = await self.http.post(f"https://artio-80085-faucet-api-cf.berachain.com/api/claim?address={self.account.address}",params=params,data=json.dumps(params))
        return True

    #查看钱包余额
    async def get_balance(self):
        bera_balance = await self.w3.eth.get_balance(self.account.address)
        return bera_balance

async def process_task(acountForLog,privatekey):
    logger.info(f"账户{acountForLog}领水开始")
    
    try:
        bera = BeraChainTools(private_key=privatekey)

        #获取领水以前的钱包余额
        row_bera_balance = await bera.get_balance()
        logger.info(f"账户{acountForLog}的bera链领水前余额为：{row_bera_balance}")

        #获取领水用的验证码
        isGetTokenSuccess = await bera.get_TaskResult(acountForLog)
        if isGetTokenSuccess:
            await bera.claim_bera()
        for _ in range(10):
            bera_balance = await bera.get_balance()
            if bera_balance - row_bera_balance == 0:
                await asyncio.sleep(2)
            elif bera_balance - row_bera_balance > 0:
                logger.info(f"账户{acountForLog}bera链领水成功!")
                logger.info(f"账户{acountForLog}的bera链领水后余额为：{bera_balance}")
                return True            
        logger.warning(f"账户{acountForLog}bera链领水失败!")
        return False
    except:
        logger.error(f"账户{acountForLog}bera链领水失败!")  
        return False

async def bera_task():
    taskArr = []
    cols = pandas.read_csv('walletKey.csv', usecols=["acount","privateKey"])
    for index, row in cols.iterrows():
        taskArr.append(process_task(f'{row.get("acount")}',row.get("privateKey")))

    try:
        await asyncio.gather(*taskArr)
    except:
        logger.error("bera链领水任务执行失败!")  

if __name__ == '__main__':
    asyncio.set_event_loop_policy(WindowsSelectorEventLoopPolicy())
    asyncio.run(bera_task())
