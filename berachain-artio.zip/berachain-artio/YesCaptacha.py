import asyncio
import sys
from typing import Union
from loguru import logger
from curl_cffi.requests import AsyncSession

logger.remove()
logger.add(sys.stdout, colorize=True, format="<g>{time:HH:mm:ss:SSS}</g> | <c>{level}</c> | <level>{message}</level>")


class YesCaptacha:
    def __init__(self,client_key,proxies):

        self.client_key = client_key
        headers = {'authority': 'artio-80085-faucet-api-cf.berachain.com',
                   'accept': '*/*',
                   'accept-language': 'zh-CN,zh;q=0.9',
                   'cache-control': 'no-cache',
                   'origin': 'https://artio.faucet.berachain.com',
                   'referer': 'https://artio.faucet.berachain.com/',
                   'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36'
                   }

        self.http = AsyncSession(timeout=120, headers=headers, impersonate="chrome120", proxies=proxies)


    async def get_yescaptcha_google_token(self,acountForLog) -> Union[bool, str]:

        json_data = {"clientKey": self.client_key,
                     "task": {"websiteURL": "https://artio.faucet.berachain.com/",
                              "websiteKey": "0x4AAAAAAARdAuciFArKhVwt",
                              "type": "TurnstileTaskProxyless"}}
        res =await self.http.post(url='https://api.yescaptcha.com/createTask', json=json_data)
        if res.json()['errorId'] != 0:
            logger.warning(f'账号{acountForLog}yescaptcha创建task失败')
        task_id = res.json()['taskId']
        await asyncio.sleep(5)
        for _ in range(30):
            data = {"clientKey": self.client_key, "taskId": task_id}
            response = await self.http.post(url='https://api.yescaptcha.com/getTaskResult', json=data)
            if response.json()['status'] == 'ready':
                return response.json()['solution']['token']
            else:
                await asyncio.sleep(3)
        return False